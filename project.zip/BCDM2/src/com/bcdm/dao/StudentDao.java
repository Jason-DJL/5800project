package com.bcdm.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.query.Query;

import com.bcdm.pojo.Customer;
import com.bcdm.pojo.Student;

public class StudentDao extends SessionBase<Student> {
	public Student getByName(String name) {
		Session s=getSession();
		s.beginTransaction();
		Query<Student> q=s.createQuery("select a  from Student a where a.name=:name ");
		q.setString("name", name);
		Student d=null;
	
		try{
			List<Student> list=q.getResultList();
			if(list.size()>0)d= list.get(0);
		
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		finally {
			s.getTransaction().commit();
			s.close();
		}
		return  d;
	}
}
