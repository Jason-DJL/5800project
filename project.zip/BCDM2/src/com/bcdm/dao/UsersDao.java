package com.bcdm.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.query.Query;

import com.bcdm.pojo.Admin;
import com.bcdm.pojo.Users;

public class UsersDao extends SessionBase<Users> {

	public Users login(String name,String pwd) {
		Session s=getSession();
		s.beginTransaction();
		Query<Users> q=s.createQuery("select a from Users a where a.name=:name and a.pwd=:pwd");
		q.setString("name", name);
		q.setString("pwd", pwd);
		Users adm=null;
	
		try{
			List<Users> list=q.getResultList();
			if(list.size()>0)adm=list.get(0);
		
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		finally {
		s.getTransaction().commit();
		s.close();
		}
		return  adm;
		
	}
}
