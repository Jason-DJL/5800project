package com.bcdm.dao;

import com.bcdm.pojo.Foodlog;

public class FoodlogDao extends SessionBase<Foodlog> {

}
