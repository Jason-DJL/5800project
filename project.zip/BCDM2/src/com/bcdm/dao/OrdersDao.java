package com.bcdm.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.query.Query;

import com.bcdm.pojo.Orders;
import com.bcdm.pojo.Customer;

public class OrdersDao extends SessionBase<Orders>{
	
	public List<Orders> serach(String start,String end){
		Session s=getSession();
		s.beginTransaction();
		Query<Orders> q=s.createQuery("from Orders o where o.createtime >= DATE( :start) and o.createtime <= DATE( :end) ");
		q.setString("start", start);
		q.setString("end", end);
		List<Orders> list=null;
	
		try{
			 list=q.getResultList();
			//System.out.print("order size"+list.size());
		
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		finally {
			s.getTransaction().commit();
			s.close();
		}
		return  list;
	}

}
