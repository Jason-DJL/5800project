package com.bcdm.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.query.Query;

import com.bcdm.pojo.Professor;
import com.bcdm.pojo.Student;

public class ProfessorDao extends SessionBase<Professor> {
	public Professor getByName(String name) {
		Session s=getSession();
		s.beginTransaction();
		Query<Professor> q=s.createQuery("select a  from Professor a where a.name=:name ");
		q.setString("name", name);
		Professor d=null;
	
		try{
			List<Professor> list=q.getResultList();
			if(list.size()>0)d= list.get(0);
		
		}catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			s.getTransaction().commit();
			s.close();
		}
		return  d;
	}
}
