package com.bcdm.dao;

import com.bcdm.pojo.Food;

public class FoodDao extends SessionBase<Food> {

}
