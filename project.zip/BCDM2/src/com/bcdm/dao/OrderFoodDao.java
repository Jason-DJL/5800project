package com.bcdm.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.query.Query;

import com.bcdm.pojo.Orderfood;
import com.bcdm.pojo.Orders;

public class OrderFoodDao extends SessionBase<Orderfood> {
	
	public List<Orderfood > getByOrderid(int id){
		Session s=getSession();
		s.beginTransaction();
		Query<Orderfood> q=s.createQuery("from Orderfood o where o.orderid=:id ");
		q.setInteger("id", id);
		
		List<Orderfood> list=null;
	
		try{
			 list=q.getResultList();
			//System.out.print("order size"+list.size());
		
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		finally {
			s.getTransaction().commit();
			s.close();
		}
		return  list;
	}

}
