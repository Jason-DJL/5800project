package com.bcdm.dao;


import java.util.List;

import org.hibernate.Session;
import org.hibernate.query.Query;

import com.bcdm.pojo.Admin;


public class AdminDao extends SessionBase<Admin> {

	public Admin login(String name,String pwd) {
		Session s=getSession();
		s.beginTransaction();
		Query<Admin> q=s.createQuery("select a from Admin a where a.name=:name and a.pwd=:pwd");
		q.setString("name", name);
		q.setString("pwd", pwd);
	 Admin adm=null;
	
		try{
			List<Admin> list=q.getResultList();
			if(list.size()>0)adm=list.get(0);
		
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		finally {
		s.getTransaction().commit();
		s.close();
		}
		return  adm;
		
	}
}
