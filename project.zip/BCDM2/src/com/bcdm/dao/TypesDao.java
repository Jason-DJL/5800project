package com.bcdm.dao;

import com.bcdm.pojo.Types;

public class TypesDao extends SessionBase<Types> {

	
	
}
