package com.bcdm.dao;

import java.sql.Date;

import com.bcdm.pojo.Orders;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UsersDao d=new UsersDao();
		d.login("qujia", "123");
	}
}
