package com.bcdm.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.query.Query;


import com.bcdm.pojo.Admin;
import com.bcdm.pojo.Usertype;

public class UserTypeDao  extends SessionBase<Usertype>{
	public Usertype getByName(String name) {
		Session s=getSession();
		s.beginTransaction();
		Query<Usertype> q=s.createQuery("from Usertype a where a.name=:name ");
		q.setString("name", name);
		Usertype d=null;
	
		try{
			List<Usertype> list=q.getResultList();
			if(list.size()>0)d= list.get(0);
		
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		finally {
			s.getTransaction().commit();
			s.close();
		}
		return  d;
	}
}
