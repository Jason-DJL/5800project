package com.bcdm.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.lang.reflect.ParameterizedType;
public class SessionBase<T> implements BaseDao<T> {
	
	private Class entityClass;
	private String hql;
	T t;
	private SessionFactory sessionFactory;
	
	
	public Session getSession(){
		return sessionFactory.getCurrentSession();
	}
	
	
	
	public SessionBase() {
		
		entityClass=(Class) ((ParameterizedType) this.getClass().getGenericSuperclass()).getActualTypeArguments()[0];
		System.out.println(entityClass);
		this.hql = "from " + entityClass.getName();
		sessionFactory =new Configuration().
		        configure("hibernate.cfg.xml").
		        addAnnotatedClass(entityClass). buildSessionFactory();
	}
	
	@Override
	public synchronized void  add(Object entity) {
		Session s=this.getSession();
		s.beginTransaction();
		s.save(entity);
		s.getTransaction().commit();
		s.close();
		
	}
 
	@Override
	public synchronized void delete(Object entity) {
		Session s=this.getSession();
		s.beginTransaction();
		s.delete(entity);
		s.getTransaction().commit();
		s.close();
	}
 
	@Override
	public synchronized void update(Object entity) {
		Session s=this.getSession();
		s.getTransaction().begin();
		s.update(entity);
		s.getTransaction().commit();
		s.close();
	}
	
	@Override
	public T findById(Integer id) {
		Session s=this.getSession();
		s.getTransaction().begin();
		T result = (T) s.get(entityClass,id);
		s.getTransaction().commit();
		s.close();
		return result;
	}
 
 
	@Override
	public synchronized List<T> getPageList(int startIndex, int pageSize) {
		Session s=this.getSession();
		s.getTransaction().begin();
		List<T> list = s.createQuery(hql).setFirstResult(startIndex).setMaxResults(pageSize).list();
		s.getTransaction().commit();
		s.close();
		return list;
	}
 
 
	@Override
	public long getAmount() {
		Session s=this.getSession();
		s.getTransaction().begin();
		String sql = "select count(*) from "+ this.entityClass.getName();
		long count =  (Long) this.getSession().createQuery(sql).uniqueResult() ;
		s.getTransaction().commit();
		s.close();
		return count;
	}

	

}
