package com.bcdm.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.query.Query;

import com.bcdm.pojo.Customer;
import com.bcdm.pojo.Usertype;

public class CustomerDao extends SessionBase<Customer> {
	public Customer getByName(String name) {
		Session s=getSession();
		s.beginTransaction();
		Query<Customer> q=s.createQuery("select a from Customer a where a.name=:name ");
		q.setString("name", name);
		Customer d=null;
	
		try{
			List<Customer> list=q.getResultList();
			if(list.size()>0)d= list.get(0);
		
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		finally {
			s.getTransaction().commit();
			s.close();
		}
		return  d;
	}
}
