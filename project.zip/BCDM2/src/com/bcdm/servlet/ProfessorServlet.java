package com.bcdm.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bcdm.dao.ProfessorDao;
import com.bcdm.dao.UsersDao;
import com.bcdm.pojo.Professor;
import com.bcdm.pojo.Student;
import com.bcdm.pojo.Users;

@WebServlet("/professor")
public class ProfessorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       ProfessorDao dao=new ProfessorDao();
       UsersDao udao=new UsersDao();
   
    public ProfessorServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String ac=request.getParameter("ac");
		response.setContentType("application/json;charset=utf-8");
		PrintWriter out=response.getWriter();
		if(ac==null)ac="list";
		if("list".equals(ac)) {
			
			out.write(Result.success(dao.getPageList(0, 9999)));		
			
		}
		
		else if("save".equals(ac)) {
			String name=request.getParameter("name");
			String depart=request.getParameter("depart");
			String research=request.getParameter("research");
			
			Integer id=Integer.parseInt(request.getParameter("id"));
			Professor u=new Professor();
			u.setName(name);u.setDepart(depart);u.setResearch(research);
			u.setId(id);
			dao.update(u);
			out.write(Result.success());
		}
		else if("add".equals(ac)) {
			String pwd=request.getParameter("pwd");
			if(pwd==null)pwd="123";
			String name=request.getParameter("name");
			String depart=request.getParameter("depart");
			String research=request.getParameter("research");
			
			
			Professor u=new Professor();
			u.setName(name);u.setDepart(depart);u.setResearch(research);
			
			dao.add(u);
			Users uu=new Users();
			uu.setName(name);uu.setType("sumtomer");uu.setPwd("123");
			udao.add(uu);
			out.write(Result.success());
		}
		
		else if("del".equals(ac)) {
			Integer id=Integer.parseInt(request.getParameter("id"));
			Professor u=dao.findById(id);
			if(u!=null)dao.delete(u);
			out.write(Result.success());
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
