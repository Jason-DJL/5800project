package com.bcdm.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bcdm.dao.FoodDao;
import com.bcdm.dao.OrderFoodDao;
import com.bcdm.dao.OrdersDao;
import com.bcdm.pojo.Orderfood;
import com.bcdm.pojo.Orders;

@WebServlet("/order")
public class OrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	OrdersDao odao=new OrdersDao();
	OrderFoodDao ofdao=new OrderFoodDao();
	FoodDao fdao=new FoodDao();
	SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
       
   
    public OrderServlet() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String ac=request.getParameter("ac");
		response.setContentType("application/json;charset=utf-8");
		PrintWriter out=response.getWriter();
		if(ac==null)ac="list";
		if("list".equals(ac)) {
			List<Orders> list=odao.getPageList(0, 99999);
			out.write(Result.success(list));
		}
		else if("add".equals(ac)) {
			String name=request.getParameter("name");
			double price=Double.parseDouble(request.getParameter("price"));
			double  discount=Double.parseDouble(request.getParameter("discount"));
			String type=request.getParameter("type");
			Orders o=new Orders();
			o.setCreatetime(new Date(System.currentTimeMillis()));
			o.setDiscount(discount);
			o.setPrice(price);
			o.setPay(discount*price);
			o.setType(type);
			o.setUsername(name);
			odao.add(o);
			out.write(Result.success(o));
			
		}
		else if("food".equals(ac)) {
			String name=request.getParameter("name");
			double price=Double.parseDouble(request.getParameter("price"));
			int num=Integer.parseInt(request.getParameter("num"));
			int orderid=Integer.parseInt(request.getParameter("oid"));
			Orderfood of=new Orderfood();
			of.setFoodname(name);
			of.setNum(num);
			of.setOrderid(orderid);
			of.setPrice(price);
			ofdao.add(of);
			out.write(Result.success());
			
		}
		else if("search".equals(ac)) {
			
			String start=request.getParameter("start");
			String end=request.getParameter("end");
			if(start==null || start.length()==0)start="1971-1-1";
			if(end==null || end.length()==0) {
				end="3021-1-1";
			}
			List<Orders> list=odao.serach(start, end);
			System.out.print("order size "+list.size());
			out.write(Result.success(list));
		
		}
		else if("get".equals(ac)) {
			int id=Integer.parseInt(request.getParameter("oid"));
			Orders o=odao.findById(id);
			out.write(Result.success(o));
		}
		
		else if("getfood".equals(ac)) {
			int id=Integer.parseInt(request.getParameter("oid"));
			List<Orderfood> o=ofdao.getByOrderid(id);
			out.write(Result.success(o));
		}
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
