package com.bcdm.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bcdm.dao.StudentDao;
import com.bcdm.dao.UsersDao;
import com.bcdm.pojo.Customer;
import com.bcdm.pojo.Student;
import com.bcdm.pojo.Users;

/**
 * Servlet implementation class StudentServlet
 */
@WebServlet("/student")
public class StudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	StudentDao dao=new StudentDao();
    UsersDao udao=new UsersDao();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("application/json;charset=utf-8");
		String ac=request.getParameter("ac");
		PrintWriter out=response.getWriter();
		if(ac==null)ac="list";
		if("list".equals(ac)) {
			
			out.write(Result.success(dao.getPageList(0, 9999)));		
			
		}
		
		else if("save".equals(ac)) {
			String name=request.getParameter("name");
			String major=request.getParameter("major");
			String starttime=request.getParameter("starttime");
			String endtime=request.getParameter("endtime");
			Integer id=Integer.parseInt(request.getParameter("id"));
			String tel=request.getParameter("tel");
			String address=request.getParameter("address");
			String zip=request.getParameter("zip");
			
			Student u=new Student();
			u.setName(name);u.setTel(tel);u.setAddress(address);u.setZip(zip);u.setMajor(major);u.setStarttime(starttime);u.setEndtime(endtime);
			u.setId(id);
			dao.update(u);
			out.write(Result.success());
		}
		else if("add".equals(ac)) {
			String pwd=request.getParameter("pwd");
			if(pwd==null)pwd="123";
			String name=request.getParameter("name");
			String tel=request.getParameter("tel");
			String address=request.getParameter("address");
			String zip=request.getParameter("zip");
			
			String major=request.getParameter("major");
			String starttime=request.getParameter("starttime");
			String endtime=request.getParameter("endtime");
			//Integer id=Integer.parseInt(request.getParameter("id"));
			Student u=new Student();
			u.setName(name);u.setTel(tel);u.setAddress(address);u.setZip(zip);u.setMajor(major);u.setStarttime(starttime);u.setEndtime(endtime);
			//u.setId(id);
			dao.add(u);
			Users uu=new Users();
			uu.setName(name);uu.setType("sumtomer");uu.setPwd(pwd);
			udao.add(uu);
			out.write(Result.success());
		}
		
		else if("del".equals(ac)) {
			Integer id=Integer.parseInt(request.getParameter("id"));
			Student u=dao.findById(id);
			if(u!=null)dao.delete(u);
			out.write(Result.success());
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
