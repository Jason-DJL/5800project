package com.bcdm.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bcdm.dao.AdminDao;
import com.bcdm.pojo.Admin;
import com.fasterxml.jackson.databind.ObjectMapper;

@WebServlet("/admin")
public class AdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ObjectMapper om = new ObjectMapper();
	AdminDao dao=new AdminDao();
   
    public AdminServlet() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("application/json;charset=utf-8");
		String ac=request.getParameter("ac");
		
		if(ac==null) {
			ac="login";
		}
		if("login".equals(ac)) {
			String name=request.getParameter("name");
			String pwd=request.getParameter("pwd");
			Admin adm=dao.login(name, pwd);
			if(adm==null) {
				response.getWriter().write(Result.error());
				
			}
			else {
				response.getWriter().write(Result.success("success", adm));
			}
			
		}
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
