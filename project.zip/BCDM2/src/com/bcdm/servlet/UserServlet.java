package com.bcdm.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bcdm.dao.CustomerDao;
import com.bcdm.dao.ProfessorDao;
import com.bcdm.dao.StudentDao;
import com.bcdm.dao.UsersDao;
import com.bcdm.pojo.Customer;
import com.bcdm.pojo.Professor;
import com.bcdm.pojo.Student;
import com.bcdm.pojo.Users;

/**
 * Servlet implementation class UserServlet
 */
@WebServlet("/user")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
      UsersDao dao=new UsersDao();
      StudentDao sdao=new StudentDao();
      ProfessorDao pdao=new ProfessorDao();
      CustomerDao cdao=new CustomerDao();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String ac=request.getParameter("ac");
		response.setContentType("application/json;charset=utf-8");
		PrintWriter out=response.getWriter();
		if(ac==null)ac="list";
		if("login".equals(ac)) {
			String name=request.getParameter("name");
			String pwd=request.getParameter("pwd");
			Users u=dao.login(name, pwd);
			if(u==null) {
				out.write(Result.error("name or pwd error"));	
				return;
			}
			
			String t=u.getType();
			System.out.print("usertype"+t);;
			if("student".equals(t)) {
				Student s=sdao.getByName(name);
				u.setExt(s);
				
			}
			else if("professor".equals(t)) {
				Professor p=pdao.getByName(name);
				u.setExt(p);
			}
			else {
				System.out.println("customer info");
				Customer c=cdao.getByName(name);
				u.setExt(c);
			}
			
			out.write(Result.success(u));		
			
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
