package com.bcdm.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bcdm.dao.FoodDao;
import com.bcdm.dao.FoodlogDao;
import com.bcdm.dao.TypesDao;
import com.bcdm.pojo.Food;
import com.bcdm.pojo.Foodlog;
import com.bcdm.pojo.Types;
import com.bcdm.pojo.Customer;

@WebServlet("/food")
public class FoodServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
     FoodDao fdao=new FoodDao();
     TypesDao tdao=new TypesDao();
     FoodlogDao ldao=new FoodlogDao();

    public FoodServlet() {
        super();
    }



	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String ac=request.getParameter("ac");
		response.setContentType("application/json;charset=utf-8");
		PrintWriter out=response.getWriter();
		if(ac==null)ac="list";
		if("list".equals(ac)) {
			List<Food> list=fdao.getPageList(0, 9999);
			out.write(Result.success(list));
		}
		else if("type".equals(ac)) {
			List<Types> list=tdao.getPageList(0, 9999);
			out.write(Result.success(list));
		}
		else if("add".equals(ac)) {
			String name=request.getParameter("name");
			String type=request.getParameter("type");
			double price=Double.parseDouble(request.getParameter("price"));
			String remark =request.getParameter("remark");
			Food f=new Food();
			f.setName(name);f.setPrice(price);f.setRemark(remark);
			f.setType(type);
			fdao.add(f);
			
			Foodlog log=new Foodlog();
			log.setName(name);log.setPrice(price);log.setRemark("NewFood");
			log.setType(type);
			ldao.add(log);
			
			out.write(Result.success());
			
		}
		else if("save".equals(ac)) {
			Integer id=Integer.parseInt(request.getParameter("id"));
			String name=request.getParameter("name");
			String type=request.getParameter("type");
			double price=Double.parseDouble(request.getParameter("price"));
			String remark =request.getParameter("remark");
			Food f=new Food();
			f.setId(id);
			f.setName(name);f.setPrice(price);f.setRemark(remark);
			f.setType(type);
			fdao.add(f);
			
			
			Foodlog log=new Foodlog();
			log.setName(name);log.setPrice(price);log.setRemark("UpdateFoodinfo");
			log.setType(type);
			ldao.add(log);
			out.write(Result.success());
			
		}
		else if("del".equals(ac)) {
			Integer id=Integer.parseInt(request.getParameter("id"));
			Food u=fdao.findById(id);
			if(u!=null)fdao.delete(u);
			out.write(Result.success());
		}
		else if("log".equals(ac)) {
			
			List<Foodlog> log=ldao.getPageList(0, 9999);
			out.write(Result.success(log));
			
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
