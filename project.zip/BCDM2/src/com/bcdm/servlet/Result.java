package com.bcdm.servlet;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;

public class Result {
	private static ObjectMapper om = new ObjectMapper();
	
	public static String result(int code,String msg,Object data){
		Map<String, Object> map=new HashMap<String,Object>();
		map.put("code", code);
		map.put("msg", msg);
		if(data!=null)map.put("data", data);
		String s="";
		try {
			s=om.writeValueAsString(map);
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		return s;
	}
	public static String result(int code,String msg){
	
		return result(code,msg,null);
	}
	
	public static String success(String msg,Object data){
		
		return result(0,msg,data);
	}
	
	public static String success(String msg){
	
		return success(msg,null);
	}
	public static String success(Object data){
		
		return success("success",data);
	}
	
	public static String success(){
		
		return success("success");
	}
	
	
	public static String error(String msg){
	
		return result(1,msg,null);
	}
	public static String error(int code,String msg){
		
		return result(code,msg,null);
	}
	
	public static String error(){
		
		return error("error");
	}
	
	

}
