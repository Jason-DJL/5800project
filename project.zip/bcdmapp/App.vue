<script>
	var BasePath="http://127.0.0.1:8080/";//服务器基础路径
	var Api=BasePath+"BCDM/";//api 路径
	export default {
		request:function(d){
			
			if(d==''){
				console.error("request param cant be null");
				return;
			}
			if(d.url=='' || d.url==undefined){
				console.error("url cant be null");
				return;
			}
			
			if(d.method=='' || d.method==undefined)d.method='POST'
			d.url=Api+d.url;//完整路径
			if(d.data==null || d.data==undefined)d.data={};//带上一个参数
			d.header={}
		    d.header['content-type']= 'application/x-www-form-urlencoded';
			
			
			if(d.fail==null){
				d.fail=function(res){
					console.log(res);
					uni.stopPullDownRefresh();
					uni.showToast({
						title:'网络异常'
					})
				}
			}
			var callback=null;
			if(d.success!=null){
				callback=d.success;
			}
			//console.log(d);
			d.success=function(res){
				if(res.statusCode==200){
					//console.log(res);
					if(typeof(res)=='string'){
						res=JSON.parse(res);
					}
					if(callback!=null)callback(res.data);
					uni.stopPullDownRefresh();
				}
				else{
					uni.showToast({
						title:'网络异常'
					})
				}
			}
			uni.request(d);
		},
		onLaunch: function() {
			console.log('App Launch')
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style>
	/*每个页面公共css */
</style>
