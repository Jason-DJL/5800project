<template>
	<view>
		<view class="logo">
			Sys Login
		</view>
		
		<view class="ipt">			
			<label>name</label><input v-model="user.name" />
		</view>
		
		<view class="ipt">			
			<label>pwd</label><input v-model="user.pwd" />
		</view>
		
		
		<button type="primary" @click="login"> login </button>
		
	</view>
</template>

<script>
	import app from "../../App.vue"
	export default {
		data() {
			return {
				user:{},
				types:['customer','student','professor'],
				cur:0
			}
		},
		methods: {
			doselect(e){
				console.log(e)
				this.cur=e.target.value;
				this.user.type=this.types[this.cur];
			},
			login(){
				app.request({
					url:'user?ac=login',
					data:this.user,
					success:function(res){
						if(res.code==0){
							uni.setStorageSync('user',res.data)
							uni.showToast({
								title:res.msg,
								success: () => {
									uni.switchTab({
										url:'../index/index'
									})
								}
							})
							
						}
						else{
							uni.showToast({
								title:res.msg
							})
						}
					}
				})
			}
		}
	}
</script>

<style>
.logo{ margin-top: 160upx; text-align: center; font-size: larger; color: #3F536E;}
.ipt{ width: 100%; box-sizing: border-box; padding: 20upx 30upx; margin-top: 10upx; align-items: center; display: flex;  height: 80upx;}
.ipt label{ width: 100upx;}
.ipt input{ flex: 1 1 auto;border: solid 1px #999; border-radius: 5upx;line-height: 80upx;height: 80upx; text-indent: 1em; }
.ipt picker{ flex: 1 1 auto;border: solid 1px #999; border-radius: 5upx;line-height: 80upx;height: 80upx;text-indent: 1em;}
button{ margin: 40upx;}
</style>
