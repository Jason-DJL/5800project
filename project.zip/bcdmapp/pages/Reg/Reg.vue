<template>
	<view>
		<view class="type">
			<view class="it" @click="showtype(k)" v-for="(i,k) in types" :class="{on:cur==k}">{{i}}</view>
		</view>
		
		<view v-if="cur==0">
			<view class="logo">
				Regist Customer
			</view>
			<view class="ipt">
				
				<label>name</label><input v-model="cus.name" />
			</view>
			
			<view class="ipt">			
				<label>pwd</label><input v-model="cus.pwd" />
			</view>
			
			<view class="ipt">
				<label>tel</label><input v-model="cus.tel" />
			</view>
			<view class="ipt">
				<label>address</label><input v-model="cus.address" />
			</view>
			<view class="ipt">
				<label>zip</label><input v-model="cus.zip" />
			</view>
		
			<button type="primary" @click="regcus"> regist </button>
			
		</view>
		
		<view v-if="cur==1">
			<view class="logo">
				Regist Student
			</view>
			<view class="ipt">
				
				<label>name</label><input v-model="stu.name" />
			</view>
			
			<view class="ipt">			
				<label>pwd</label><input v-model="stu.pwd" />
			</view>
			
			<view class="ipt">
				<label>marjor</label><input v-model="stu.marjor" />
			</view>
			<view class="ipt">
				<label>start</label><input v-model="stu.starttime" />
			</view>
			<view class="ipt">
				<label>end</label><input v-model="cus.endtime" />
			</view>
		
			<button type="primary" @click="regstu"> regist </button>
			
		</view>
		
		<view v-if="cur==2">
			<view class="logo">
				Regist Professor
			</view>
			<view class="ipt">
				
				<label>name</label><input v-model="pro.name" />
			</view>
			
			<view class="ipt">			
				<label>pwd</label><input v-model="pro.pwd" />
			</view>
			
			<view class="ipt">
				<label>marjor</label><input v-model="pro.depart" />
			</view>
			<view class="ipt">
				<label>research</label><input v-model="pro.research" />
			</view>
			
		
			<button type="primary" @click="regpro"> regist </button>
			
		</view>
	</view>
</template>

<script>
	import app from "../../App.vue"
	export default {
		data() {
			return {
				user:{},
				types:['customer','student','professor'],
				cur:0,
				cus:{type:'customer'},
				stu:{},
				pro:{}
			}
		},
		methods: {
			showtype(k){
				this.cur=k;
				//this.curtype=this.types[k];
			},
			doselect(e){
				console.log(e)
				this.cur=e.target.value;
				this.user.type=this.types[this.cur];
			},
			regstu(){
				app.request({
					url:'student?ac=add',
					data:this.stu,
					success:function(r){
						uni.showToast({
							title:tr.msg
						})
					}
				})
			},
			regcus(){
				app.request({
					url:'customer?ac=add',
					data:this.cus,
					success:function(r){
						uni.showToast({
							title:tr.msg
						})
					}
				})
			},
			regpro(){
				app.request({
					url:'professor?ac=add',
					data:this.pro,
					success:function(r){
						uni.showToast({
							title:tr.msg
						})
					}
				})
			}
		}
	}
</script>

<style>
	.type{height: 80upx; background: #F0AD4E; color: #fff; display: flex; margin-bottom: 30upx;}
	.type .it{ flex:  1 1 auto; text-align: center; line-height: 80upx;}
	.type .it.on{ background: #DD524D;}
.logo{ margin-top: 160upx; text-align: center; font-size: larger; color: #3F536E;}
.ipt{ width: 100%; box-sizing: border-box; padding: 20upx 30upx; margin-top: 10upx; align-items: center; display: flex;  height: 80upx;}
.ipt label{ width: 100upx;}
.ipt input{ flex: 1 1 auto;border: solid 1px #999; border-radius: 5upx;line-height: 80upx;height: 80upx; text-indent: 1em; }
.ipt picker{ flex: 1 1 auto;border: solid 1px #999; border-radius: 5upx;line-height: 80upx;height: 80upx;text-indent: 1em;}
button{ margin: 40upx;}
</style>
