<template>
	<view>
		<view class="b30"></view>
		<view class="foods">
			
			<view class="fi">
				<view class="name">Food</view> <view class="price">Price</view> 
				<view class="n">remark</view>
			</view>
			<view class="fi" v-for="(v,k) in list" :key="k">
				<view class="name">{{v.name}}</view> <view class="price">${{v.price}}</view> 
				<view class="n">{{v.remark}}</view>
			</view>
			
			
		</view>
	</view>
</template>

<script>
	import app from "../../App.vue"
	export default {
		data() {
			return {
				list:[]
			}
		},
		onPullDownRefresh() {
			this.loadData()
		},
		onLoad() {
			this.loadData();
		},
		methods: {
			loadData()
			{
				var pg=this;
				app.request({
					url:'food?ac=log',
					success:function(r){
						pg.list=r.data
					}
				})
			}
		}
	}
</script>

<style>
.b30{height: 30upx;}
.type{height: 80upx; background: #F0AD4E; color: #fff; display: flex; }
.type .it{ flex:  1 1 auto; text-align: center; line-height: 80upx;}
.type .it.on{ background: #DD524D;}
.foods{ width: 100%;  box-sizing: border-box;}
.foods .fi{ display: flex;padding: 20upx 20upx; color: #3F536E;}
.foods .fi view{ flex: 1 1 auto; text-align: center;}
</style>
