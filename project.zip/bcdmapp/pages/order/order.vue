<template>
	<view>
		
		<view class="time">
			<input v-model="start" @input="loadData" /> <view>-</view>   <input v-model="end" @input="loadData" />
		</view>
		<view class="b30"></view>
		<view class="foods">
			<view class="fi" v>
				<view class="name">name</view>  <view class="price">type</view>  <view class="price">price</view> 
				 <view class="price">discount</view> 
				<view class="price">pay</view> 
			</view>
			<view class="fi" v-for="(i,k) in list " :key="k">
				<view class="name">{{i.username}}</view>  <view class="price">{{i.type}}</view>  <view class="price">{{i.price}}</view> 
				 <view class="price">{{i.discount}}</view> 
				<view class="price">{{i.pay}}</view> 
			</view>
			
		</view>
				<view class="h200"></view>
		<view class="sum">
			<view class="count">count:{{count}}</view> <view class="pay">${{sum}}</view>
		</view>
	</view>
</template>

<script>
	import app from "../../App.vue"
	export default {
		data() {
			return {
				start:'2021-1-1',end:"2021-12-30",
				types:['all','Paying','Haing','Completed'],
				curtype:'',
				cur:0,
				sum:0,count:8,
				list:[]
				
			}
		},
		onLoad() {
			this.loadData()
		},
		methods: {
			showtype(k){
				this.cur=k;
				this.curtype=this.types[k];
			},
			loadData()
			{
				var pg=this;
				app.request({
					url:'order?ac=search&start='+this.start+'&end='+this.end,
					success:function(res){
						if(res.code==0){
							var arr=res.data;
							
							pg.list=arr
							pg.count=arr.length;
							var s=0
							for(var i=0;i<arr.length;i++){
								s+=arr[i].pay;
							}
							pg.sum=parseInt(s*100)/100;
						}
						else{
							uni.showToast({
								title:res.msg
							})
						}
					}
				})
			}
		}
	}
</script>

<style>
.b30{height: 30upx;}
.type{height: 80upx; background: #F0AD4E; color: #fff; display: flex; }
.type .it{ flex:  1 1 auto; text-align: center; line-height: 80upx;}
.type .it.on{ background: #DD524D;}
.foods{ width: 100%;  box-sizing: border-box;}
.foods .fi{ display: flex;padding: 20upx 20upx; color: #3F536E;}
.foods .fi view{ flex: 1 1 auto; text-align: center;}
.time{ background: #f0f0f0; line-height: 80upx; display: flex; box-sizing: border-box; padding: 10upx 20upx; align-items: center;}
.time input{ border: solid 1px #f3f3f3; line-height: 70upx; background: #fff; border-radius: 20upx; text-align: center; height: 70upx; flex: 1 1 auto;}
.sum{ height: 80upx; width: 100%; background: #DD524D; line-height: 80upx; position: fixed; bottom: 90upx; left: 0; display: flex; }
.sum .count{ flex: 1 1 auto; font-size: small; color: #fff; text-align: right; padding-right: 40upx;}
.sum .pay{font-size: 60upx; color: #fff; padding-right: 80upx;}
.h200{height: 150upx;}
</style>
