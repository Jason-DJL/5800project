<template>
	<view class="content">
		<view class="type">
			<view class="it" @click="showtype(k)" v-for="(i,k) in types" :class="{on:cur==k}">{{i}}</view>
		</view>
		<view class="foods">
			
			<view class="fi" >
				<view class="name">name</view> <view class="price">type</view> <view class="price">price</view> 
				<view class="n" ></view> <view class="n"> </view><view class="n" > </view>
			</view>
			
			<view class="fi" v-for="(i,k) in list" :key='k' v-if="curtype==i.type || curtype=='all'">
				<view class="name">{{i.name}}</view> <view class="price">{{i.type}}</view> <view class="price">${{i.price}}</view> 
				<view class="i" @click="desc(k)">-</view><view class="n">{{i.num}}</view><view class="i" @click="add(k)">+</view>
			</view>
			
			
		</view>
		
		<view class="h200"></view>
		<view class="sum">
			<view class="l">			
				<view >count:{{count}}</view> <view >sum:${{sum}}</view> <view>{{user.type}}:{{discount}} </view><view class="pay">${{sum*discount}}</view>
				<button @click="doorder">order</button>
			</view>
			
		</view>
	</view>
</template>

<script>
	import app from "../../App.vue"
	export default {
		data() {
			return {
				types:['all','food','drink','other'],
				curtype:'all',
				cur:0,
				sum:0,
				count:8,
				discount:1,
				list:[],
				ftypes:[{id:'',name:'---'}],
				fcur:0,
				o:{type:'customer',name:'123'},
				user:{}
			}
		},
		onLoad() {
			this.user=uni.getStorageSync('user');
			this.loadData()
			this.loadType()
		},
		onPullDownRefresh() {
			this.loadData()
			this.loadType()
		},
		methods: {
			showtype(k){
				this.cur=k;
				this.curtype=this.types[k];
			},
			loadData()
			{
				var pg=this;
				app.request({
					url:'food?ac=list',
					success:function(res){
						if(res.code==0){
							var arr=res.data;
							for(var i=0;i<arr.length;i++){
								arr[i].num=0;
							}
							pg.list=arr
						}
						else{
							uni.showToast({
								title:res.msg
							})
						}
					}
				})
			},
			loadType()
			{
				var pg=this;
				app.request({
					url:'customer?ac=type',
					success:function(res){
						console.log("types",res)
						pg.ftypes=res.data;
						pg.o.type=pg.ftypes[0].name
						pg.fcur=0;
						pg.discount=1;
						for(var i=0;i<res.data.length;i++){
							if(res.data[i].name==pg.user.type){
								pg.discount=res.data[i].discount;
								return
							}
						}
					}
				})
			},
			changetype(i){
				
				var k=i.detail.value;
				console.log("ftype ",k)
				var t=this.ftypes[k];
				this.discount=t.discount;
				this.fcur=k;
				this.getSum()
			},
			desc(k){
				var n=this.list[k].num;
				if(n>0){
					n--;
					this.list[k].num=n;
				}
				this.getSum();
			},
			add(k){
				var n=this.list[k].num;				
				n++;
				this.list[k].num=n;
				this.getSum();
			},
			getSum(){
				var sum=0;
				var c=0;
				for(var i=0;i<this.list.length;i++){
					c+=this.list[i].num;
					sum+=this.list[i].num*this.list[i].price;
				}
				this.count=c;
				this.sum=sum;
			},
			doorder()
			{
				var pg=this;
				var d={name:this.user.name,discount:this.discount,type:this.user.type,price:this.sum};
				app.request({
					url:'order?ac=add',
					data:d,
					success(res){
						if(res.code==0){
							var oid=res.data.id;
							for(var i=0;i<pg.list.length;i++){
								var f=pg.list[i];
								if(f.num>0){
									var d1={oid:oid,name:f.name,num:f.num,price:f.price}
									app.request({
										url:'order?ac=food',
										data:d1,
										success:function(r){}
									})
								}
							}
							
						}
						else{
							uni.showToast({
								title:res.msg
							})
						}
					}
				})
			}
		}
	}
</script>

<style>
.type{height: 80upx; background: #F0AD4E; color: #fff; display: flex; margin-bottom: 30upx;}
.type .it{ flex:  1 1 auto; text-align: center; line-height: 80upx;}
.type .it.on{ background: #DD524D;}
.foods{ width: 100%;  box-sizing: border-box;}
.foods .fi{ display: flex;padding: 20upx 20upx; color: #3F536E;}
.foods .fi .name{flex: 1 1 auto;}
.foods .fi .price{flex: 1 1 auto;}
.foods .fi .i{ width: 40upx; height: 40upx; border-radius: 40upx; background: #007AFF; color: #fff; text-align: center; line-height: 40upx; flex: 0 0 auto;}
.foods .fi .n{ width: 40upx; text-align: center;}
.sum{ height: 80upx; width: 100%; background: #DD524D; line-height: 80upx; position: fixed; z-index: 99; bottom: 90upx; left: 0; }
.sum .l{display: flex; color: #fff; height: 80upx; align-items: center;}
.sum .l view{ flex: 1 1 auto; font-size: small; color: #fff; text-align: center;}
.sum .l .pay{font-size: 60upx;}
.sum .l input{ background: #fff; color: #333333; text-align: center; border-radius: 10upx; width: 280upx; height: 80upx; }
.sum .l picker{ width: 200upx; height: 80upx; text-align: center;}
.h200{ height: 200upx;}
</style>
