package newpackage.net;

import bcdmclient.pojo.Result;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

public class NetTool {
    
    private static ObjectMapper om=new ObjectMapper();
    
    private static  String basepath="http://127.0.0.1:8080/BCDM/"; 
  
	public static String doPost(String url, String postData) {
		String result = null;
		HttpPost post = null;
		try {
			HttpClient client = new DefaultHttpClient();
			
			post = new HttpPost(basepath+url);
 
			post.setHeader(HTTP.CONTENT_TYPE, "application/json; charset=UTF-8");
			post.setHeader("Accept", "application/json; charset=UTF-8");
			if(postData!=null){
                            StringEntity entity = new StringEntity(postData, "UTF-8");
                            post.setEntity(entity);
                        }
			
			
			HttpResponse response = client.execute(post);
 
			int rspCode = response.getStatusLine().getStatusCode();
			System.out.println("rspCode:" + rspCode);
			result = EntityUtils.toString(response.getEntity(), "UTF-8");
			
			return result;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(post != null) {
				post.releaseConnection();
			}
		}
		return null;
        }
        
        public static Result doRequest(String url,String data){
            String r=doPost(url,data);
            System.out.println("response = "+r);
            if(r==null)return null;
            else {
                try{
                 Result rst =om.readValue(r, Result.class);
                 return rst;
                }
                catch(Exception e){
                    e.printStackTrace();
                    return null;
                }
            
            }
            
        }
         public static Result doRequest(String url){
          return doRequest(url,null);
            
        }
        



}
