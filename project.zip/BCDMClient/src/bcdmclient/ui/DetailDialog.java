
package bcdmclient.ui;

import bcdmclient.pojo.Orderfood;
import bcdmclient.pojo.Orders;
import bcdmclient.pojo.Result;
import java.util.List;
import newpackage.net.NetTool;

public class DetailDialog extends javax.swing.JDialog {

  
    public DetailDialog(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
    }

    @SuppressWarnings("unchecked")
    
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        txt = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        txt.setEditable(false);
        txt.setColumns(20);
        txt.setRows(5);
        jScrollPane1.setViewportView(txt);

        jLabel1.setText("OrderDetail");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(104, 104, 104)
                .addComponent(jLabel1)
                .addContainerGap(124, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 466, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }

   public void showOrder(int id){
       Result r=NetTool.doRequest("order?ac=get&oid="+id);
       Orders o=r.getObject(Orders.class);
       Result t=NetTool.doRequest("order?ac=getfood&oid="+id);
       List<Orderfood> list=t.getList(Orderfood.class);
       for(Orderfood f : list){
           String s= f.getFoodname()+"\t"+f.getPrice()+"\tx"+f.getPrice()+"\r\n";
           txt.append(s);
       }
       txt.append("customer："+o.getUsername()+"\r\n");
       txt.append("type："+o.getType()+"\r\n");
       txt.append("sum："+o.getPrice()+"\tdiscount:"+o.getDiscount()+"\r\n");
       txt.append("pay："+o.getPay()+"\r\n");
       
   }
   

  
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea txt;

}
