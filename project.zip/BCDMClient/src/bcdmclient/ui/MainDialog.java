package bcdmclient.ui;

import bcdmclient.pojo.Food;
import bcdmclient.pojo.Orders;
import bcdmclient.pojo.Result;
import bcdmclient.pojo.Usertype;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.JDialog;
import newpackage.net.NetTool;

public class MainDialog extends javax.swing.JDialog implements FoodEvent  {

    public MainDialog(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        this.oitems = new HashMap<String,OrderItem>();
        initComponents();
        loadFood();
        loadType();
    }

 
    @SuppressWarnings("unchecked")
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btnFood = new javax.swing.JButton();
        btnUser = new javax.swing.JButton();
        btnOrder = new javax.swing.JButton();
        btnStudent = new javax.swing.JButton();
        btnProfessor = new javax.swing.JButton();
        btnLog = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        orderPane = new javax.swing.JPanel();
        doOrder = new javax.swing.JButton();
        lblPrice = new javax.swing.JLabel();
        lblSum = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtUserName = new javax.swing.JTextField();
        cboType = new javax.swing.JComboBox<>();
        jPanel4 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        FoodPanel = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("BCDM");

        btnFood.setText("Food");
        btnFood.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnFoodMouseClicked(evt);
            }
        });

        btnUser.setText("Customer");
        btnUser.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnUserMouseClicked(evt);
            }
        });

        btnOrder.setText("Orders");
        btnOrder.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnOrderMouseClicked(evt);
            }
        });

        btnStudent.setText("Student");
        btnStudent.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnStudentMouseClicked(evt);
            }
        });

        btnProfessor.setText("Professor");
        btnProfessor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnProfessorMouseClicked(evt);
            }
        });

        btnLog.setText("LOGS");
        btnLog.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnLogMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnFood, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnUser, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnStudent, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnProfessor, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnOrder, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnLog, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(186, 186, 186))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btnFood, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnUser, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnStudent, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(btnProfessor, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(btnOrder, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(btnLog, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jLabel1.setText("CurrentFoods");

        orderPane.setBackground(new java.awt.Color(255, 255, 255));
        orderPane.setLayout(null);

        doOrder.setText("DoOrder");
        doOrder.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                doOrderMouseClicked(evt);
            }
        });

        lblPrice.setFont(new java.awt.Font("宋体", 0, 36)); // NOI18N
        lblPrice.setForeground(new java.awt.Color(255, 0, 0));
        lblPrice.setText("$55.25");

        lblSum.setText("$60.55 discount:0.9");

        jLabel5.setText("username");

        txtUserName.setToolTipText("");

        cboType.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboTypeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(19, 19, 19)
                                .addComponent(jLabel1))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                        .addComponent(lblSum)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(lblPrice))
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addComponent(jLabel5)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(txtUserName)))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(doOrder, javax.swing.GroupLayout.DEFAULT_SIZE, 173, Short.MAX_VALUE)
                                    .addComponent(cboType, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addGap(0, 10, Short.MAX_VALUE))
                    .addComponent(orderPane, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(orderPane, javax.swing.GroupLayout.PREFERRED_SIZE, 411, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtUserName, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboType, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPrice)
                    .addComponent(lblSum, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(doOrder, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17))
        );

        jLabel2.setText("ALLFood");

        FoodPanel.setLayout(null);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel2))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(FoodPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 560, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(FoodPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 964, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(7, 7, 7)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }

    private void doOrderMouseClicked(java.awt.event.MouseEvent evt) {
        String url="order?ac=add&name="+this.txtUserName.getText()+"&price="+String.format("%.2f", sum)+"&discount="+usType.getDiscount()+"&type="+usType.getName();
        Result t=NetTool.doRequest(url);
        if(t.getCode()==0){
            Orders od=t.getObject(Orders.class);
            for(String  k : oitems.keySet()){
                oitems.get(k).saveOrder(od.getId());
            }
            oitems.clear();
            orderPane.removeAll();
            doReSum();
            
            DetailDialog d=new DetailDialog(new javax.swing.JFrame(),true);
            d.showOrder(od.getId());
            d.setVisible(true);
            
        }
        orderPane.setVisible(false);
         orderPane.setVisible(true);
        this.revalidate();
        
        
    }

    private void btnUserMouseClicked(java.awt.event.MouseEvent evt) {
        CumtomerDialog d=new CumtomerDialog(new javax.swing.JFrame(),true);
        d.setVisible(true);
    }

    private void btnFoodMouseClicked(java.awt.event.MouseEvent evt) {
         FoodDialog d=new FoodDialog(new javax.swing.JFrame(),true);
        d.setVisible(true);
    }

    private void btnOrderMouseClicked(java.awt.event.MouseEvent evt) {
         OrderDialog d=new OrderDialog(new javax.swing.JFrame(),true);
        d.setVisible(true);
    }

    private void btnStudentMouseClicked(java.awt.event.MouseEvent evt) {
         JDialog d=new StudentDialog(new javax.swing.JFrame(),true);
        d.setVisible(true);
    }

    private void btnProfessorMouseClicked(java.awt.event.MouseEvent evt) {
         JDialog d=new PorfessorDialog(new javax.swing.JFrame(),true);
        d.setVisible(true);
    }

    private void btnLogMouseClicked(java.awt.event.MouseEvent evt) {
         JDialog d=new LogDialog(new javax.swing.JFrame(),true);
        d.setVisible(true);
    }

    private void cboTypeActionPerformed(java.awt.event.ActionEvent evt) {
        int i=cboType.getSelectedIndex();
        System.out.print(i);
        usType=ts.get(i);
        discount=usType.getDiscount();
        doReSum();
    }
   
    void loadFood()
    {
        Result r=NetTool.doRequest("food", "?ac=list");
        List<Food> fd=r.getList(Food.class);
        System.out.println("good length"+fd.size());
        int startx=10;
        int starty=10;
        for(Food f : fd){
            System.out.println(f.getName()+"  "+f.getPrice());
            FoodItem it=new FoodItem();
            it.setFood(f);
            it.setBounds(startx,starty,108,108);
            FoodPanel.add(it);
            it.setFoodEvent(this);
            startx+=118;
            if(startx+118>FoodPanel.getWidth()){
                startx=10;
                starty+=118;
            }
        }
        
    }
    List<Usertype> ts;
    
    void loadType()
    {
        Result t=NetTool.doRequest("customer?ac=type");
       ts=t.getList(Usertype.class);
        for(Usertype o :ts){
            cboType.addItem(o.getName());
        }
    }
    

    private javax.swing.JPanel FoodPanel;
    private javax.swing.JButton btnFood;
    private javax.swing.JButton btnLog;
    private javax.swing.JButton btnOrder;
    private javax.swing.JButton btnProfessor;
    private javax.swing.JButton btnStudent;
    private javax.swing.JButton btnUser;
    private javax.swing.JComboBox<String> cboType;
    private javax.swing.JButton doOrder;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JLabel lblPrice;
    private javax.swing.JLabel lblSum;
    private javax.swing.JPanel orderPane;
    private javax.swing.JTextField txtUserName;

    
    Map<String,OrderItem> oitems;
    double sum;
    double discount=1;
    double price;
    Usertype usType;
    @Override
    public void doFoodClick(Food f) {
        String k=f.getId()+"";
         if(oitems.containsKey(k)){
            OrderItem i=oitems.get(k);
            i.doAdd();
        }
        else{
            OrderItem it=new OrderItem();
            it.setFood(f);
            it.setFoodEvent(this);
            
            int c=oitems.size();
            it.setBounds(10,10+ c*50, 400    , 45);
            orderPane.add(it);
            
            oitems.put(k, it);
            doReSum();
        }
    }
    
    @Override
    public void doReSum() {
        sum=0;
        for(OrderItem i : oitems.values()){
            sum+=i.getSum();
        }
        lblSum.setText(String.format("Sum:%.2f dis:%.2f",sum,discount));
        price=discount*sum;
        lblPrice.setText(String.format("$%.2f", price));
        
    }

    @Override
    public void delOrderItem(Food f) {
        String k=f.getId()+"";
        if(oitems.containsKey(k)){
            OrderItem i=oitems.remove(k);
            orderPane.remove(i);
        }
        int c=0;
        for(String kk : oitems.keySet()){
            OrderItem it=oitems.get(kk);
            it.setBounds(10, c*50, 400    , 45);
            c++;
        }
    }
}
