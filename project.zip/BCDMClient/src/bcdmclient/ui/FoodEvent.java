package bcdmclient.ui;

import bcdmclient.pojo.Food;

public interface FoodEvent {
    void doFoodClick(Food f);
    void doReSum();
    void delOrderItem(Food f);
    
}
