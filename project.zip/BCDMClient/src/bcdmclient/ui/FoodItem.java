package bcdmclient.ui;

import bcdmclient.pojo.Food;
import java.awt.Dimension;

public class FoodItem extends javax.swing.JPanel {

    public FoodItem() {
        initComponents();
    }
    
    Food food;
    public void  setFood(Food f){
        this.food=f;
        lblName.setText(f.getName());
        lblPrice.setText("$"+f.getPrice()+" ");
        lblType.setText(f.getType());
        this.setPreferredSize(new Dimension(108,108));
        this.setVisible(true);
    }


    @SuppressWarnings("unchecked")
    private void initComponents() {

        lblName = new javax.swing.JLabel();
        lblPrice = new javax.swing.JLabel();
        lblType = new javax.swing.JLabel();

        setBackground(new java.awt.Color(153, 204, 255));
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                formMouseClicked(evt);
            }
        });

        lblName.setFont(new java.awt.Font("宋体", 0, 18));
        lblName.setForeground(new java.awt.Color(51, 0, 51));
        lblName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        lblPrice.setFont(new java.awt.Font("宋体", 0, 18)); 
        lblPrice.setForeground(new java.awt.Color(255, 0, 102));
        lblPrice.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPrice.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        lblType.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblType.setText("jLabel1");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblName, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(lblPrice, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(lblType, javax.swing.GroupLayout.DEFAULT_SIZE, 108, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblName, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblType, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }

    private void formMouseClicked(java.awt.event.MouseEvent evt) {
        System.out.println("Food clicked");
        if(foodEvent!=null){
            foodEvent.doFoodClick(food);
        }
    }
    FoodEvent foodEvent;
    public void setFoodEvent(FoodEvent e){
        this.foodEvent=e;
    }

    private javax.swing.JLabel lblName;
    private javax.swing.JLabel lblPrice;
    private javax.swing.JLabel lblType;
}
