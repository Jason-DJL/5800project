package bcdmclient.ui;

import bcdmclient.pojo.Food;
import bcdmclient.pojo.Result;
import java.awt.Dimension;
import newpackage.net.NetTool;


public class OrderItem extends javax.swing.JPanel {

    public OrderItem() {
        initComponents();
        this.setVisible(true);
        this.setPreferredSize(new Dimension(446,45));
    }

  
    @SuppressWarnings("unchecked")
    private void initComponents() {

        lblName = new javax.swing.JLabel();
        lblPrice = new javax.swing.JLabel();
        lblSum = new javax.swing.JLabel();
        btnDesc = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        lblNum = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(400, 46));

        lblPrice.setFont(new java.awt.Font("宋体", 0, 12)); // NOI18N
        lblPrice.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        btnDesc.setText("-");
        btnDesc.setActionCommand("");
        btnDesc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnDescMouseClicked(evt);
            }
        });

        jButton1.setText("+");
        jButton1.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                jButton1MouseDragged(evt);
            }
        });
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });

        lblNum.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblName, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblSum, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 48, Short.MAX_VALUE)
                .addComponent(btnDesc)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblNum, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton1)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblPrice, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblSum, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblNum, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblName, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                        .addComponent(btnDesc)
                        .addComponent(jButton1)))
                .addContainerGap())
        );
    }

    private void btnDescMouseClicked(java.awt.event.MouseEvent evt) {
        if(this.num>0){
            this.num--;
            reCount();
        }
        else{
            foodEvent.delOrderItem(food);
        }
    }

    private void jButton1MouseDragged(java.awt.event.MouseEvent evt) {
    }

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {
            this.num++;
            reCount();
    }

    public void doAdd()
    {
        this.num++;
        reCount();
    }
    
    public void setFood(Food f){
    this.food=f;
    lblName.setText(f.getName());
    lblPrice.setText("$"+f.getPrice());
    lblSum.setText(""+num*f.getPrice());
    lblNum.setText(num+"");
    }
    void reCount()
    {
        lblSum.setText(""+num*food.getPrice());
        lblNum.setText(num+"");
        foodEvent.doReSum();
    }
    int num=1;
    
    public double getSum()
    {
        return num*food.getPrice();
    }
    
   FoodEvent foodEvent;
    public void setFoodEvent(FoodEvent e){
        this.foodEvent=e;
    }
    Food food;
    
    public void saveOrder(int id){
        String url="order?ac=food&name="+food.getName()+"&price="+food.getPrice()+"&num="+num+"&oid="+id;
        System.out.print(url);
        Result r=NetTool.doRequest(url);
    }

    private javax.swing.JButton btnDesc;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel lblName;
    private javax.swing.JLabel lblNum;
    private javax.swing.JLabel lblPrice;
    private javax.swing.JLabel lblSum;
}
