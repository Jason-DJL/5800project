package bcdmclient.ui;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class MyModel  implements  TableModel{
    String col[];
    List dat;
    public MyModel(List d){
        
        setData(d);
    }
     public MyModel(){
       
        
    }
     public void setData(List d){
         if(d==null|| d.size()==0) return;
         dat=d;
        Map m= (Map)dat.get(0);
        int i=0;
        col=new String[m.size()];
        for(Object k : m.keySet()){
            col[i]=k.toString();
            i++;
        }
     }

    @Override
    public int getRowCount() {
        if(dat==null || dat.size()==0) return 0;
      return dat.size();
    }

    @Override
    public int getColumnCount() {
          if(dat==null || dat.size()==0) return 0;
       return col.length;
    }

    @Override
    public String getColumnName(int columnIndex) {
          if(dat==null || dat.size()==0) return "";
        return col[columnIndex];
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        return String.class;
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return false;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
          if(dat==null || dat.size()==0) return "";
        Map m= (Map)dat.get(rowIndex);
        return m.get(col[columnIndex]);
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        
    }

    @Override
    public void addTableModelListener(TableModelListener l) {
       
    }

    @Override
    public void removeTableModelListener(TableModelListener l) {
       
    }
    
    public Map getRow(int i){
          if(dat==null || dat.size()==0) return null;
       return (Map) dat.get(i);
    }
    
    
    
}
