
package bcdmclient.pojo;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.List;

public class Result {
    private static ObjectMapper om=new ObjectMapper();
    private String msg;
    private Integer code;
    private Object data;
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public Integer getCode() {
		return code;
	}
	public void setCode(Integer code) {
		this.code = code;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
        
        public <T> T getObject(Class<T> c){
            T t=null;
            try{
                String con=om.writeValueAsString(data);
                t=om.readValue(con, c);
            
            }catch(Exception e){
            e.printStackTrace();
            }
            
            return t;
        }
     public <T> List<T> getList(Class<T> c){
          
            List<T> list=new ArrayList<T>();
            
            try{
                
               List arr=(List)data;
               for(Object o : arr ){
                String con=om.writeValueAsString(o);
             
               T t=om.readValue(con, c);
               list.add(t);
               }
              
            
            }catch(Exception e){
            e.printStackTrace();
            }
            
            return list;
        }
      

}